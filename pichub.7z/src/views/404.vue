<template>
    <n-result status="404" title="404 资源不存在" description="虽然你不可能错，但我们确实没找到" />
</template>

<script setup>
    import { NResult } from "naive-ui";
</script>

<style scoped>

</style>